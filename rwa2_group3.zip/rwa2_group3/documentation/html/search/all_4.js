var searchData=
[
  ['turnleft_14',['turnLeft',['../class_simulator.html#ab103b5780fb3102441270df9c006e435',1,'Simulator']]],
  ['turnright_15',['turnRight',['../class_simulator.html#af3e20b66f7372a26639a2ecf6f881490',1,'Simulator']]]
];

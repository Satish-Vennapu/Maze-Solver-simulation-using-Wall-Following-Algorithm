var searchData=
[
  ['setcolor_31',['setColor',['../class_simulator.html#ae77656a3dea16067d95ca727c36afaab',1,'Simulator']]],
  ['settext_32',['setText',['../class_simulator.html#aa033cf7d80338a24678b95ec6f69b371',1,'Simulator']]],
  ['setwall_33',['setWall',['../class_simulator.html#aa0e3277ba6aeba683eb5888ba637a477',1,'Simulator']]]
];

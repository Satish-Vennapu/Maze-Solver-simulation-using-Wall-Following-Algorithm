var searchData=
[
  ['setcolor_9',['setColor',['../class_simulator.html#ae77656a3dea16067d95ca727c36afaab',1,'Simulator']]],
  ['settext_10',['setText',['../class_simulator.html#aa033cf7d80338a24678b95ec6f69b371',1,'Simulator']]],
  ['setwall_11',['setWall',['../class_simulator.html#aa0e3277ba6aeba683eb5888ba637a477',1,'Simulator']]],
  ['simulator_12',['Simulator',['../class_simulator.html',1,'']]],
  ['simulator_2eh_13',['simulator.h',['../simulator_8h.html',1,'']]]
];
